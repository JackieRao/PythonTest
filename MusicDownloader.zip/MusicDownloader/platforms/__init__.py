# __init__
# from platforms.kugou import kugou
# from platforms.qq import qq
__all__ = ['kugou', 'qq']